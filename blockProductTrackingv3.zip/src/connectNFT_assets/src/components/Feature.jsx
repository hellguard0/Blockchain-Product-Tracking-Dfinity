import React, { useEffect, useState } from "react";
import concertImage from "../../assets/concert.png";
import alifImage from "../../assets/alifsafar.png";
import Card from 'react-bootstrap/Card';

function Feature() {

  return (
    <div className="body-content">
      <div className="featured mt-1">
        <div className="d-flex flex-column gap-3">
          <h3 className="my-0 text-start">Featured</h3>
          <Card className="bg-dark text-white rounded-5">
            <Card.Img src={concertImage} className="rounded-5" alt="Card image" />
            <Card.ImgOverlay>
              <Card.Title>Alif Satar Malaysia Concert</Card.Title>
              <Card.Text>
                <button className="btn-mint">Mint Now</button>
              </Card.Text>
            </Card.ImgOverlay>
          </Card>
          <Card className="bg-dark text-white rounded-5">
            <Card.Img src={alifImage} className="rounded-5" alt="Card image" />
            <Card.ImgOverlay>
              <Card.Title>Alif Satar NFT</Card.Title>
              <Card.Text>
                <button className="btn-mint">Mint Now</button>
              </Card.Text>
            </Card.ImgOverlay>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default Feature;
