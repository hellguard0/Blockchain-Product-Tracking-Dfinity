import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import Item from "./Item";
import Minter from "./Minter";

import { defaultProviders } from "@connect2ic/core/providers"
import { createClient } from "@connect2ic/core"
import { PlugWallet } from "@connect2ic/core/providers/plug-wallet"
import { Connect2ICProvider } from "@connect2ic/react"
import { ConnectButton, ConnectDialog, Connect2ICProvider, useConnect } from "@connect2ic/react"
import "@connect2ic/core/style.css"

function App() {
  // const NFTID = "rrkah-fqaaa-aaaaa-aaaaq-cai";

  const { isConnected, principal, activeProvider } = useConnect({
    onConnect: () => {
      // Signed in
    },
    onDisconnect: () => {
      // Signed out
    }
  })

  return (
    <div className="App">
      <Header />
      {/* <Minter /> */}
      {/* <Item id={NFTID}/> */}
      {/* <div className="auth-section">
        <ConnectButton />
      </div>
      <ConnectDialog /> */}
      <Footer />
    </div>
  );
}

const client = createClient({
  providers: [
    new PlugWallet(),
  ],
  // globalProviderConfig: {
  //   dev: import.meta.env,
  // },
})

export default () => (
  <Connect2ICProvider client={client}>
    <App />
  </Connect2ICProvider>
)
