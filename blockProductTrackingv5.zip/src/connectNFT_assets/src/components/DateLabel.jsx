import React from "react";

function PriceLabel(props) {
  return (
    <div className="disButtonBase-root disChip-root makeStyles-price-24">
      <span className="disChip-label">28 Oct</span>
    </div>
  );
}
export default PriceLabel;
