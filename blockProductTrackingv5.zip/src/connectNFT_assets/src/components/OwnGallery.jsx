import React, { useEffect, useState } from "react";
import OwnItem from "./OwnItem";
import { Principal } from "@dfinity/principal";
import Input from '@mui/material/Input';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import concertImage from "../../assets/concert.png";
import { BiSearch } from "react-icons/bi";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types'

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box>
          {children}
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

function OwnGallery(props) {
  const [items, setItems] = useState();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  function fetchNFTs() {
    if (props.ids != undefined) {
      setItems(
        props.ids.map((NFTId) => (
          <OwnItem id={NFTId} key={NFTId.toText()} role={props.role} />
        ))
      );
    }
  }

  useEffect(() => {
    fetchNFTs();
  }, []);

  return (
    <div className="body-content">
      <div className="featured mt-1">
        <div className="d-flex flex-column gap-3">
          <h3 className="my-0 text-start">NFT List</h3>
          <FormControl variant="standard" className="search-form">
            <Input
              className="search-input"
              id="input-with-icon-adornment"
              placeholder="Search Related"
              endAdornment={
                <InputAdornment position="end">
                  <BiSearch className="search-icons" />
                </InputAdornment>
              }
            />
          </FormControl>
          <div className="d-flex flex-column gap-4">
            <Box>
              <Tabs
                value={value}
                onChange={handleChange}
                variant="scrollable"
                scrollButtons="auto"
                aria-label="scrollable auto tabs example"
                className="btn-category"
              >
                <Tab label="My Active NFT" />
                <Tab label="Expired NFT" />
                <Tab label="NFT Create" />
              </Tabs>
            </Box>
            <TabPanel value={value} index={0}>
              <div className="d-flex flex-column gap-3">
                {items}
              </div>
            </TabPanel>
            <TabPanel value={value} index={1}>
              <div className="d-flex flex-column gap-3">
                {items}
              </div>
            </TabPanel>
            <TabPanel value={value} index={2}>
              <div className="d-flex flex-column gap-3">
                {items}
              </div>
            </TabPanel>
          </div>
          
        </div>
      </div>
    </div>
  );
}

export default OwnGallery;
