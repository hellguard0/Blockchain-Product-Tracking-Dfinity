import React from "react";

function ListedLabel(props) {
  return (
    <div className="disButtonBase-root disChip-root makeStyles-price-24">
      <span className="disChip-label">Listed</span>
    </div>
  );
}
export default ListedLabel;
